insert into student values(1, 'abc', 'xyz', 'pqr');
