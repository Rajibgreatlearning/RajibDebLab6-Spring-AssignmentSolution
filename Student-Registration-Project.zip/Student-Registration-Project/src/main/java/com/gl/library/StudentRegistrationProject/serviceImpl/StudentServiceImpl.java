package com.gl.library.StudentRegistrationProject.serviceImpl;

import java.util.ArrayList;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gl.library.StudentRegistrationProject.entity.Student;
import com.gl.library.StudentRegistrationProject.repository.StudentRegistrationProjectRepo;
import com.gl.library.StudentRegistrationProject.service.StudentService;
@Service
public class StudentServiceImpl implements StudentService{
	@Autowired
	StudentRegistrationProjectRepo srp;

	@Override
	public void addStudent(Student student) {
		srp.save(student);
		srp.flush();		
	}

	@Override
	public List<Student> getAllStudent() {
		List<Student> students=new ArrayList<Student>();
		students=srp.findAll();
		return students;
	}

	@Override
	public Student getStudentById(int id) {
		Student student=new Student();
		student=srp.findById(id).get();
		return student;
	}

	@Override
	public String updateStudent(int id, String newFirstName, String newLastName, String newEmail) {
		
		return null;
	}

	@Override
	public void deleteStudentById(int id) {
		
		srp.deleteById(id);
	}

}
