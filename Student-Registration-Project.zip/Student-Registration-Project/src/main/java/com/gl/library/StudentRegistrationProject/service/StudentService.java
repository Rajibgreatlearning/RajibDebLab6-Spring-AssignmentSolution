package com.gl.library.StudentRegistrationProject.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.gl.library.StudentRegistrationProject.entity.Student;


public interface StudentService {	

		  /*add employee details in H2 database*/
		   void addStudent(Student student);
		   	   
		  /* read employee details from H2 database*/
		   List<Student> getAllStudent();	 
		   Student getStudentById(int id);
		  	   
		   /*update employee details in H2 database*/
		   String updateStudent(int id,String newFirstName, String newLastName, String newEmail);
		   
		   /*delete employee in H2 database*/	   
		   void deleteStudentById(int id);
	}


