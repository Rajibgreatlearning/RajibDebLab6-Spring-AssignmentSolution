package com.gl.library.StudentRegistrationProject.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gl.library.StudentRegistrationProject.entity.Student;

public interface StudentRegistrationProjectRepo extends JpaRepository<Student, Integer> {

}
