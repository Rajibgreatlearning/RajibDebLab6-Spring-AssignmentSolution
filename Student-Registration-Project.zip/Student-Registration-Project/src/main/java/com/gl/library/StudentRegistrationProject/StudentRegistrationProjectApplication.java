package com.gl.library.StudentRegistrationProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentRegistrationProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentRegistrationProjectApplication.class, args);
		System.out.println("Welcome to Student registration page");
	}

}
